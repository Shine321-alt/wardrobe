import '../../styles/ProductInfo.css'
import ProductSize from './ProductInfo/ProductSize'
import ProductColors from './ProductInfo/ProductColors'

export default function ProductInfo({
    product,
    colors,
    sizes,
    selectedColorId,
    selectedSizeId,
    selectedSize,
    setSelectedColorId,
    setSelectedSizeId
}) {
    return (
        <div className='product-info'>

            <ProductTitle
                Name={product.Product_Name}
                Category={product.Category}
                Price={selectedSize?.Price}
            />

            <ProductColors
                color={colors}
                selectedColorId={selectedColorId}
                setSelectedColorId={setSelectedColorId}
            />

            <ProductSize
                size={sizes}
                selectedSizeId={selectedSizeId}
                setSelectedSizeId={setSelectedSizeId}
            />

            <button
                className={`product-add-btn ${!selectedSizeId ? 'product-add-btn--disabled' : ''}`}
                disabled={!selectedSizeId}
            >
                {selectedSizeId
                    ? `Add to Cart — Size ${selectedSize?.Size_Name}`
                    : `Select a Size`}
            </button>

            <div className="product-description">
                <p>{product.Description}</p>
            </div>

        </div>
    )
}
